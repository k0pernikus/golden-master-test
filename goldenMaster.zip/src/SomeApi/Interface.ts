export interface SomeApiPost {
    body: string;
    id: number;
    title: string;
    userId: number;
}
